package com.example.employeemanagement.util;

public enum UserRole {
    SUPER_ADMIN,
    ADMIN,
    EMPLOYEE,
}
