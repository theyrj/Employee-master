package com.example.employeemanagement.service.admin;

public interface AdminService {
}
