package com.example.employeemanagement.service.admin;

import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {
}
