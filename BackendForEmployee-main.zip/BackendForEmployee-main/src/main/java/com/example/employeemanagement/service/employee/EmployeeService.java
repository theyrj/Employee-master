package com.example.employeemanagement.service.employee;

public interface EmployeeService {
}
